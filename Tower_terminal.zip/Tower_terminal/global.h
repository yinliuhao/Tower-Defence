#ifndef GLOBALS_H
#define GLOBALS_H

#include "map.h"   // 记得包含 Map 类的头文件

extern Map* gMap;   //  只声明，不定义！

#endif
