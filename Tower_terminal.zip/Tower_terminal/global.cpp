#include "global.h"

Map* gMap;   //  真正定义（分配内存）
