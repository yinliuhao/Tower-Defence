#include "bulletmanager.h"

BulletManager::BulletManager(QObject*) {}
